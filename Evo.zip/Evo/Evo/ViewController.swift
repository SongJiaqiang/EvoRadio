//
//  ViewController.swift
//  Evo
//
//  Created by Jarvis on 2019/3/6.
//  Copyright © 2019 SongJiaqiang. All rights reserved.
//

import Cocoa
import Alamofire

class ViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        let url = "https://www.lavaradio.com/api/play.playProgram.json?&device=iPhone%20OS%209.3&&luid=NgDXJv3Ua8Wr9c16oWrYaSRSgHW7w2nJrvDJYqh8wmV%2FEZNttdQljvGg2naofMJ6eRKUd6nFLMGq98B%2F%2FX%2FBeyhDlCr8wjPUpPDOLfh6wC0sFpJ5oMA30A%3D%3D&&program_id=6938"
        Alamofire.request(url).responseJSON { (rsp) in
            print("rsp => \(rsp)")
        }
        
        
    }

    
    
    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }


}

class API {
    
    /// 
    /// https://www.lavaradio.com/api/radio.listAllChannels.json
    class func fetchAllRadios() {
        let url = "https://www.lavaradio.com/api/radio.listAllChannels.json"
        
        Alamofire.request(url).responseJSON { (rsp) in
            print("rsp => \(rsp)")
        }
    }
    
    /// https://www.lavaradio.com/api/radio.listAllChannels.json
    class func fetchAllChannels() {
        let url = "https://www.lavaradio.com/api/radio.listAllChannels.json"
        
        Alamofire.request(url).responseJSON { (rsp) in
            print("rsp => \(rsp)")
        }
    }
    
    /// https://www.lavaradio.com/api/radio.listChannelPrograms.json?channel_id=5&_pn=0&_sz=2
    class func getPrograms(channelId: Int, pageSize: Int=20, pageNum: Int=0) {
        let url = String(format: "https://www.lavaradio.com/api/radio.listChannelPrograms.json?channel_id=5&_sz=%d&_pn=%d", pageSize, pageNum)
        
        Alamofire.request(url).responseJSON { (rsp) in
            print("rsp => \(rsp)")
        }
    }
    
    /// https://www.lavaradio.com/api/play.playProgram.json?program_id=6938
    class func fetchSongs(programId: Int) {
        let url = String(format: "https://www.lavaradio.com/api/play.playProgram.json?program_id=%d", programId)
        
        Alamofire.request(url).responseJSON { (rsp) in
            print("rsp => \(rsp)")
        }
    }
}

